declare class DOMException {
  constructor(message: string, name: string)
}

export default DOMException
