export declare const isFunction: (value: unknown) => value is Function;
