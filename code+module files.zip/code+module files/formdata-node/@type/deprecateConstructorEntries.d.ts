export declare const deprecateConstructorEntries: () => void;
