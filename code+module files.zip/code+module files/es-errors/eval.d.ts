declare const EvalError: EvalErrorConstructor;

export = EvalError;
