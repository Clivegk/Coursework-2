// GENERAL NOTES
// to use chatGpt you need to run a server
// to interact with it so this here is said server
// which will use http call services to interact with you main page
// require nodeJs and can be run with the command
// node server.mjs and make sure its running for anything to work
// you know it will work because it will say its listening
// on some port

// Required libraries so
// npm install openai (handles ChatGPT)
// npm install express (handles Sever stuff)
// npm install cors (Handles browser security things)
// this is if you do not use the nodes_module included
// and in the package.json its updated to type: module
import OpenAI from "openai";
import express from "express";
import cors from "cors";

const openai = new OpenAI({
    // Add your api key here but mine is here for demo purpose
    apiKey: "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"
})

// Do not touch
const app = express();
const corsOptions = {
    origin: '*',
    credentials: true,
    optionSuccessStatus: 200
}
app.use(cors(corsOptions));

// If the port is taken try any other number till one is free
const port = 8080;

//message stores what you want to ask chatGpt
async function requestGpt(message){
    const response = await openai.chat.completions.create({
        messages: [{"role": "user", "content": message}],
        // Update to 4.0 or whatever version if you apprently rich
        model: "gpt-3.5-turbo"
    })
    return response.choices[0].message.content; 
}

// the /getGptReponse is the https url path for where to start the server request
// imagine it basically like a function. The req handles inputs from the html page
// res handles sending things back to said html page. The query makes it so this
// api call will look for ? in the url which will be followed by a variable name
// storing your message
app.get('/getGptResponse', async (req, res) => {
    var message = req.query.userInput;
    var data = await requestGpt(message);
    res.send(JSON.stringify(data))
})

// mainly just debug to show its running and where 
// NOTE: its acting weird on my pc and displays http://:::8080
// works though
var server = app.listen(port, () => {
    var host = server.address().address;
    var port = server.address().port;
    console.log("REST API app listening at http://%s:%s", host, port);
})
