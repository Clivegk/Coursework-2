function startDictation() {// Function to start voice recognition and handle its events
    if (window.hasOwnProperty('webkitSpeechRecognition')) {
        var recognition = new webkitSpeechRecognition();

        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = "en-US";
        recognition.start();

        recognition.onresult = function(e) {
            var query = e.results[0][0].transcript;
            document.getElementById('searchInput').value = query;
            appendMessage('User', query);
            handleSearchQuery(query);
            recognition.stop();
        };

        recognition.onerror = function(e) {
            var errorMessage = 'Sorry, I didn\'t catch that. Please try again.';
            appendMessage('System', errorMessage);
            recognition.stop();
        }
    } else {
        appendMessage('System', 'Voice recognition is not supported in this browser.');
    }
}

function appendMessage(sender, message) {// Function to append messages to the chat interface
    var chatInterface = document.getElementById('chatInterface');
    var messageElement = document.createElement('div');
    messageElement.innerHTML = sender + ': ' + message; 
    chatInterface.appendChild(messageElement);
    chatInterface.scrollTop = chatInterface.scrollHeight;

    if (sender === 'System') {
        speakText(message);
    }
}

function speakText(text) {// Function to convert text to speech
    var msg = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.speak(msg);
}


function clearChat() {// Function to clear the chat interface
    var chatInterface = document.getElementById('chatInterface');
    chatInterface.innerHTML = ''; // Clear the chat interface
    speechSynthesis.cancel(); // Stop any ongoing speech synthesis
}

function handleSearchQuery(query) {// Function to handle different search queries
    var lowerCaseQuery = query.toLowerCase();

    if (lowerCaseQuery.startsWith('library search')) {
        var bookTitle = lowerCaseQuery.replace('library search', '').trim();
        if (bookTitle) {
            redirectToLibrarySearch(bookTitle);
        } else {
            appendMessage('System', 'Please tell me the book you are searching for after saying "library Search".');
        }
    } else if (lowerCaseQuery.includes('books') || lowerCaseQuery.includes('article')) {
        searchBooks(lowerCaseQuery);
    } else if (lowerCaseQuery === 'show me library hours' || lowerCaseQuery === 'library hours') {
        getLibraryHours();
    } else if (lowerCaseQuery === 'show me library locations' || lowerCaseQuery === 'library locations') {
        showLibraryLocations();
    } else if (lowerCaseQuery === 'contact support') {
        contactSupport();
    } else {
        getResponse(lowerCaseQuery);
    }
}

function redirectToLibrarySearch(bookTitle) {
    // Function to redirect to the library search page
    var searchQuery = encodeURIComponent(bookTitle); // Encode the book title to be URL-safe
    var librarySearchUrl = `https://mdx.primo.exlibrisgroup.com/discovery/search?query=any,contains,${searchQuery}&tab=default&search_scope=Hendon_CI&vid=44MUN_INST:hendon&offset=0`; // Replace with your school's library search URL
    window.open(librarySearchUrl, '_blank'); // Open the search in a new tab
}




function getLibraryHours() {// Function to display library hours
    var libraryHours = {
        'Monday': '9:00 AM - 5:00 PM',
        'Tuesday': '9:00 AM - 5:00 PM',
        'Wednesday': '9:00 AM - 5:00 PM',
        'Thursday': '9:00 AM - 5:00 PM',
        'Friday': '9:00 AM - 5:00 PM',
        'Saturday': 'Closed',
        'Sunday': 'Closed'
    };

    var hoursMessage = '<div class="library-hours"><h2>Library Hours:</h2>';
    for (var day in libraryHours) {
        hoursMessage += `<div class="day-hour"><span class="day">${day}:</span> <span class="hour">${libraryHours[day]}</span></div>`;
    }
    hoursMessage += '</div>';

    appendMessage('System', 'Here are the library hours:');
    appendMessage('System', hoursMessage);
}


function showLibraryLocations() {// Function to show library locations on the map
    var mapMessage = 'Showing library locations on the map.';
    appendMessage('System', mapMessage);
    document.getElementById('map').style.display = 'block'; // Show the map
    initMap(); // Initialize the map
}




function initMap() {// Function to initialize the Google Maps
    const map = new google.maps.Map(document.getElementById('map'), {
        zoom: 10,
        center: { lat: -20.348404, lng: 57.552152 } // Center the map over Mauritius
    });

    const libraryLocations = [
        { lat: -20.237097998940353, lng: 57.47122853328172, name: "Le Plaza Library" },
        { lat: -20.162036269867002, lng: 57.50007045434399, name: "National Library" },
        { lat: -20.231956315498824, lng: 57.49698054957006, name: "Library University Of Mauritius" },
        { lat: -20.23920429275404, lng: 57.47792613679749, name: "Mediatheque" },
        { lat: -20.161875127543016, lng: 57.50384700462324, name: "Léoville L'Homme City Library" },
        { lat: -20.31518304386117, lng: 57.52691250660469, name: "Bibliothèque Carnegie" },
        { lat: -20.268973882845618, lng: 57.475757416458535, name: "Carrefour Library" },
        { lat: -20.21907018824145, lng: 57.46814143834671, name: "Voice of God library" }
    ];

    // Place markers for each library
    libraryLocations.forEach((location) => {
        new google.maps.Marker({
            position: { lat: location.lat, lng: location.lng },
            map: map,
            title: location.name
        });
    });
}

function getResponse(){ // Function to get a response from the server based on the user's input
    var message = document.getElementById("searchInput").value;
    var apiUrl = "http://localhost:8080/getGptResponse?userInput="+message;
    fetch(apiUrl).then(async response => {
        if(!response.ok){
            console.log("Network error");
            return;
        }
        var response = await response.json();
        appendMessage("System", response)
    })
}

function searchBooks(query) {// Function to search for books using Google Books API
    var apiKey = 'AIzaSyBkCWwJhEr20fGu4KCCNTZtvH8wlEYfQDE';
    var apiUrl = `https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(query)}&key=${apiKey}`;

    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            if (data.totalItems > 0) {
                var introMessage = `Here are books about ${query.replace(/show me books about /i, '')}`;
                speakText(introMessage);
                appendMessage('System', introMessage);

                var booksMessage = '<ul class="book-results">';
                data.items.forEach(book => {
                    var title = book.volumeInfo.title;
                    var authors = book.volumeInfo.authors ? book.volumeInfo.authors.join(', ') : 'Unknown Author';
                    var thumbnail = book.volumeInfo.imageLinks ? book.volumeInfo.imageLinks.thumbnail : '';
                    var previewLink = book.volumeInfo.previewLink;

                    booksMessage += `<li class="book">
                        <div class="book-info">
                            <img src="${thumbnail}" alt="${title}">
                            <div>
                                <h3>${title}</h3>
                                <p>By ${authors}</p>
                                <a href="${previewLink}" target="_blank">Preview</a>
                            </div>
                        </div>
                    </li>`;
                });
                booksMessage += '</ul>';
                appendMessage('System', booksMessage);
            } else {
                appendMessage('System', 'No books or articles found. Please try a different search.');
            }
        })
        .catch(error => {
            console.error('Error fetching books:', error);
            appendMessage('System', 'An error occurred while searching for books. Please try again later.');
        });
}

///Function that generates a calendar in the home page
function generateCalendar() {
    var today = new Date();
    var currentMonth = today.getMonth();
    var currentYear = today.getFullYear();

    var firstDayOfMonth = new Date(currentYear, currentMonth, 1);
    var lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0);
    var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    var monthName = months[currentMonth];
    var calendar = document.getElementById('calendar');
    calendar.innerHTML = ''; // Clear the calendar

    // Create the month-year header
    var monthYearHeader = document.createElement('div');
    monthYearHeader.classList.add('month-year');
    monthYearHeader.textContent = `${monthName} ${currentYear}`;
    calendar.insertBefore(monthYearHeader, calendar.firstChild); // Insert it before the first child of the calendar


    // Fill in the blanks for days of the week before the first day of the month
    for (var i = 0; i < firstDayOfMonth.getDay(); i++) {
        var emptyCell = document.createElement('div');
        calendar.appendChild(emptyCell);
    }

    

    // Fill in the days of the month
    for (var day = 1; day <= lastDayOfMonth.getDate(); day++) {
        var dayCell = document.createElement('div');
        dayCell.classList.add('calendar-day');
        if (day === today.getDate() && currentMonth === today.getMonth()) {
            dayCell.classList.add('current-day');
        }
        dayCell.textContent = day;
        calendar.appendChild(dayCell);
    }
}

// Call the function when the page loads
window.onload = function() {
    generateCalendar();
};


function contactSupport() {
    // Function to contact support by opening an email client
    var helpDeskEmail = 'ithelpdesk@mdx.ac.mu'; 
    var subject = encodeURIComponent('Library Support Request');
    var outlookWebLink = `https://outlook.office.com/mail/deeplink/compose?to=${helpDeskEmail}&subject=${subject}`;
    window.open(outlookWebLink, '_blank');
    appendMessage('System', 'Redirecting you to Outlook to contact the library support.');
}
